public class Node {
    TreeNode data;
    Node next;

    public Node(TreeNode data) {
        this.data = data;
        this.next = null;
    }
}